# Bluetooth-Features
1.This Repository contains libraries related to Bluetooth profiles which can be used for Automation Framework development as well as testing the bluetooth devices.
2.This Project is Basically Abstract Layer for Gap operations which either end user or Application programmer can make utilize this
Api's or build any framework using it.
3.This feature adds Abstraction to the code meanwhile providing security for the backend programs by data hiding concept.
