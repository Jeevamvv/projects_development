import subprocess

subprocess.run("python constants.py", shell=True)
subprocess.run("python gap.py", shell=True)
subprocess.run("python logger_mod.py", shell=True)
subprocess.run("python trigger.py", shell=True)
subprocess.run("python utils.py", shell=True)
